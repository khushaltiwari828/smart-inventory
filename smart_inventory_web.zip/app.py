import sqlite3
from pathlib import Path

import pandas as pd
import streamlit as st

# Database is created in the same folder as this app.
DB_PATH = Path(__file__).with_name("inventory.db")


def get_connection():
    return sqlite3.connect(DB_PATH, check_same_thread=False)


def initialize_database():
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                price REAL NOT NULL CHECK(price >= 0),
                quantity INTEGER NOT NULL CHECK(quantity >= 0),
                min_stock INTEGER NOT NULL DEFAULT 5 CHECK(min_stock >= 0)
            )
        """)
        conn.commit()


def add_product(name, price, quantity, min_stock):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO products (name, price, quantity, min_stock) VALUES (?, ?, ?, ?)",
            (name.strip(), price, quantity, min_stock),
        )
        conn.commit()


def get_products(search_text=""):
    with get_connection() as conn:
        if search_text.strip():
            return pd.read_sql_query(
                "SELECT id, name, price, quantity, min_stock FROM products "
                "WHERE name LIKE ? ORDER BY name COLLATE NOCASE",
                conn,
                params=(f"%{search_text.strip()}%",),
            )
        return pd.read_sql_query(
            "SELECT id, name, price, quantity, min_stock FROM products "
            "ORDER BY name COLLATE NOCASE",
            conn,
        )


def update_quantity(product_id, quantity):
    with get_connection() as conn:
        conn.execute(
            "UPDATE products SET quantity = ? WHERE id = ?",
            (quantity, product_id),
        )
        conn.commit()


def update_product(product_id, name, price, quantity, min_stock):
    with get_connection() as conn:
        conn.execute(
            "UPDATE products SET name = ?, price = ?, quantity = ?, min_stock = ? WHERE id = ?",
            (name.strip(), price, quantity, min_stock, product_id),
        )
        conn.commit()


def delete_product(product_id):
    with get_connection() as conn:
        conn.execute("DELETE FROM products WHERE id = ?", (product_id,))
        conn.commit()


st.set_page_config(page_title="Smart Inventory System", page_icon="📦", layout="wide")
initialize_database()

st.title("📦 Smart Inventory Management System")
st.caption("Manage products, quantities, prices, and low-stock alerts.")

products = get_products()
total_products = len(products)
total_units = int(products["quantity"].sum()) if not products.empty else 0
inventory_value = float((products["price"] * products["quantity"]).sum()) if not products.empty else 0.0
low_stock = products[products["quantity"] <= products["min_stock"]] if not products.empty else products

m1, m2, m3, m4 = st.columns(4)
m1.metric("Product types", total_products)
m2.metric("Total units", total_units)
m3.metric("Inventory value", f"₹{inventory_value:,.2f}")
m4.metric("Low-stock items", len(low_stock))

if not low_stock.empty:
    st.warning("⚠️ Low stock alert: " + ", ".join(low_stock["name"].astype(str).tolist()))

tab_view, tab_add, tab_update, tab_edit_delete = st.tabs(
    ["📋 View & Search", "➕ Add Product", "🔄 Update Stock", "✏️ Edit / Delete"]
)

with tab_view:
    search = st.text_input("Search product by name", key="search_product")
    shown = get_products(search)
    if shown.empty:
        st.info("No products found. Add a product from the 'Add Product' tab.")
    else:
        display = shown.copy()
        display["price"] = display["price"].map(lambda x: f"₹{x:,.2f}")
        display["status"] = shown.apply(
            lambda row: "LOW STOCK" if row["quantity"] <= row["min_stock"] else "In stock",
            axis=1,
        )
        display = display.rename(columns={
            "id": "ID", "name": "Product", "price": "Price",
            "quantity": "Quantity", "min_stock": "Minimum stock", "status": "Status"
        })
        st.dataframe(display, use_container_width=True, hide_index=True)

    if not low_stock.empty:
        st.subheader("Items needing restock")
        st.dataframe(low_stock.rename(columns={
            "id": "ID", "name": "Product", "price": "Price",
            "quantity": "Quantity", "min_stock": "Minimum stock"
        }), use_container_width=True, hide_index=True)

with tab_add:
    st.subheader("Add a new product")
    with st.form("add_product_form", clear_on_submit=True):
        name = st.text_input("Product name")
        c1, c2, c3 = st.columns(3)
        price = c1.number_input("Price (₹)", min_value=0.0, value=0.0, step=1.0, format="%.2f")
        quantity = c2.number_input("Quantity", min_value=0, value=0, step=1)
        min_stock = c3.number_input("Minimum stock limit", min_value=0, value=5, step=1)
        submitted = st.form_submit_button("Add Product", type="primary")
        if submitted:
            if not name.strip():
                st.error("Please enter a product name.")
            else:
                add_product(name, float(price), int(quantity), int(min_stock))
                st.success(f"Product '{name.strip()}' added successfully.")
                st.rerun()

with tab_update:
    st.subheader("Update quantity")
    current = get_products()
    if current.empty:
        st.info("Add a product first.")
    else:
        options = {
            f'{int(row.id)} — {row["name"]} (current quantity: {int(row["quantity"])})': int(row.id)
            for _, row in current.iterrows()
        }
        selected_label = st.selectbox("Select product", list(options.keys()), key="update_product_select")
        selected_id = options[selected_label]
        selected_row = current[current["id"] == selected_id].iloc[0]
        new_quantity = st.number_input(
            "New quantity",
            min_value=0,
            value=int(selected_row["quantity"]),
            step=1,
            key="new_quantity",
        )
        if st.button("Save quantity", type="primary"):
            update_quantity(selected_id, int(new_quantity))
            st.success("Stock quantity updated.")
            st.rerun()

with tab_edit_delete:
    st.subheader("Edit or delete a product")
    current = get_products()
    if current.empty:
        st.info("There are no products to edit or delete.")
    else:
        options = {
            f'{int(row.id)} — {row["name"]}': int(row.id)
            for _, row in current.iterrows()
        }
        selected_label = st.selectbox("Choose product", list(options.keys()), key="edit_delete_select")
        selected_id = options[selected_label]
        row = current[current["id"] == selected_id].iloc[0]

        with st.form("edit_product_form"):
            edit_name = st.text_input("Product name", value=str(row["name"]))
            c1, c2, c3 = st.columns(3)
            edit_price = c1.number_input("Price (₹)", min_value=0.0, value=float(row["price"]), step=1.0, format="%.2f")
            edit_quantity = c2.number_input("Quantity", min_value=0, value=int(row["quantity"]), step=1)
            edit_min = c3.number_input("Minimum stock limit", min_value=0, value=int(row["min_stock"]), step=1)
            save_edit = st.form_submit_button("Save changes", type="primary")
            if save_edit:
                if not edit_name.strip():
                    st.error("Product name cannot be empty.")
                else:
                    update_product(selected_id, edit_name, float(edit_price), int(edit_quantity), int(edit_min))
                    st.success("Product updated.")
                    st.rerun()

        st.divider()
        confirm_delete = st.checkbox("I understand this will permanently delete the selected product.")
        if st.button("🗑️ Delete selected product", disabled=not confirm_delete):
            delete_product(selected_id)
            st.success("Product deleted.")
            st.rerun()

st.divider()
st.caption("Data is stored locally in inventory.db. Back up this file to keep your inventory data safe.")
