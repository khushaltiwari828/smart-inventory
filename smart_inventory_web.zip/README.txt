# Smart Inventory Management System (Browser App)

## Features
- Add products with price, quantity, and minimum-stock threshold
- Search and view products
- Update stock quantities
- Edit and delete products
- Low-stock warnings
- Summary metrics and inventory value
- SQLite database persistence

## Run on a computer
1. Install Python 3.10 or newer.
2. Open a terminal/command prompt in this folder.
3. Install dependencies:
   `pip install -r requirements.txt`
4. Start the app:
   `streamlit run app.py`
5. Your browser should open automatically. If not, visit the local URL shown in the terminal (usually `http://localhost:8501`).

## Important
GDB Online Python compiler usually cannot host a persistent Streamlit web server. Run this on your computer, or deploy it to a Streamlit-compatible hosting service. The SQLite database file (`inventory.db`) is created automatically next to `app.py`.
